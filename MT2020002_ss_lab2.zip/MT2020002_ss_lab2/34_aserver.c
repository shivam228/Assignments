#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<fcntl.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<arpa/inet.h>
#include<sys/socket.h>
int main()
{
struct sockaddr_in server,client;
int server_fd,client_fd,clientlen;
char buff[50];
server_fd = socket(AF_INET,SOCK_STREAM,0);
server.sin_family = AF_INET;
server.sin_addr.s_addr = INADDR_ANY;
server.sin_port = htons(5555);
bind(server_fd,(struct sockaddr *)&server,sizeof(server));
listen(server_fd,4);
write(1,"waiting for client\n",sizeof("waiting for client\n"));
while(1)
{
clientlen =  sizeof(client);
client_fd = accept(server_fd,(struct sockaddr *)&client,&clientlen);
write(1,"connected to client\n",sizeof("connected to client\n"));
if(!fork()){
close(server_fd);
write(client_fd,"connected to server\n",sizeof("connected to server\n"));
read(client_fd,buff,sizeof(buff));
printf("message from client->\n");
printf("%s\n",buff);
exit(0);
}
else{
close(client_fd);
}
}
close(server_fd);

return 0;
}

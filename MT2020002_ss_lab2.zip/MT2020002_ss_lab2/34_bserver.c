#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<fcntl.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<arpa/inet.h>
#include<sys/socket.h>
#include<pthread.h>
void *my_handler(void *client_fd){
int nsfd = *(int*)client_fd;
char buff[50];
write(1,"connected to client\n",sizeof("connected to client\n"));
write(nsfd,"connected to server\n",sizeof("connected to server\n"));
read(nsfd,buff,sizeof(buff));
printf("message from client ->");
printf("%s\n",buff);
return 0;
}
int main()
{
pthread_t threads;
struct sockaddr_in server,client;
int server_fd,client_fd,clientlen;
server_fd = socket(AF_INET,SOCK_STREAM,0);
server.sin_family = AF_INET;
server.sin_addr.s_addr = INADDR_ANY;
server.sin_port = htons(5555);
bind(server_fd,(struct sockaddr *)&server,sizeof(server));
listen(server_fd,4);
write(1,"waiting for client\n",sizeof("waiting for client\n"));
while(1)
{
clientlen =  sizeof(client);
client_fd = accept(server_fd,(struct sockaddr *)&client,&clientlen);
if(pthread_create(&threads,NULL,my_handler,(void*) &client_fd)<0)
{
perror("couldnot create thread");
return 1;
}
}
pthread_exit(NULL);
close(server_fd);
return 0;
}

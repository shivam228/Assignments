#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/shm.h>
union senum {
int val;
struct semid_ds *buf;
unsigned short int *array;
};
int main()
{
union senum arg;
key_t key = ftok(".",'a');
int shmid = shmget(key,1024,0777|IPC_CREAT);
char *str = (char*) shmat(shmid,(void*)0,0);
printf("id-> %d\n",shmid);
struct sembuf buf;
buf.sem_num = 0;
buf.sem_op = -1;
buf.sem_flg = 0;
int key1,semid;
key1 = ftok("4.c",'a');
semid = semget(key1,1,0);
printf("Before entering to critical section.\n");
printf("Waiting for lock\n");
semop(semid, &buf, 1);
printf("Inside critical section.\n");
printf("Enter data: ");
gets(str);
printf("Press return to exit critical section.\n");
getchar();
buf.sem_op = 1;
semop(semid, &buf, 1);
return 0;
}


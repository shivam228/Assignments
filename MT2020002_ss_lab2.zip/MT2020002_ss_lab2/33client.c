#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<fcntl.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<arpa/inet.h>
#include<sys/socket.h>
int main()
{
struct sockaddr_in server;
int server_fd;
char msg[50];
char result;
server_fd = socket(AF_INET,SOCK_STREAM,0);
server.sin_family = AF_INET;
server.sin_addr.s_addr = inet_addr("127.0.0.1");
server.sin_port = htons(8080);
write(1,"waiting for connect\n",sizeof("waiting for connect\n"));
connect(server_fd,(struct sockaddr *)&server,sizeof(server));
read(server_fd,msg,sizeof(msg));
printf("%s",msg);
write(1,"write to server:",sizeof("write to server:"));
scanf(" %[^\n]",msg);
write(server_fd,msg,sizeof(msg));
close(server_fd);
return 0;
}

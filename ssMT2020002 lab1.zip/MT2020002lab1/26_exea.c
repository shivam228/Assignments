#include<stdio.h>
int main(int argc,char *argv[],char *envp[]){

int a,b;
a =10;
b=20;
printf("Filename: %s\n",argv[0]);
printf("sum = %d\n",a+b);

return 0;
}
